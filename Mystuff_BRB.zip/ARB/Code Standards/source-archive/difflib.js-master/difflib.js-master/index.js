module.exports = require('./lib/difflib');
