/**
  *@NApiVersion 2.0
  *@NScriptType ClientScript
  */
//123
 define(['N/ui/dialog','N/search'],
     function(dialog,search) {
      function pageInitfun(Scriptcontext) 
      {
          
      }
     function fieldChangedfun(Scriptcontext) {
       
     }
    function lineInitfun(Scriptcontext) {
      
  }
 function postSourcingfun(Scriptcontext) {
  
 }
 function saveRecordfun(Scriptcontext) {
  
 }
 function sublistChangedfun(Scriptcontext) {
  
 }
 function validateDeletefun(Scriptcontext) {
  
 }
 function validateFieldfun(Scriptcontext) {
  
 }
 function validateInsertfun(Scriptcontext) {
  
 }
  return {
    pageInit: pageInitfun,
    fieldChanged: fieldChangedfun, 
    lineInit: lineInitfun,
    postSourcing: postSourcingfun,
    saveRecord: saveRecordfun,
    sublistChanged: sublistChangedfun,
    validateDelete: validateDeletefun,  
    validateField: validateFieldfun,
    validateInsert: validateInsertfun     
  };
 }); //Deploying on 11/13
