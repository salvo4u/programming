/**
 *@NApiVersion 2.x
 *@NModuleScope Public
 *@NScriptType Suitelet
 */
define(['N/log', 'N/ui/serverWidget', 'N/record', 'N/search'],
    function(log, serverWidget, record, search) {
        function onRequest(context) {
        }
 
        return {
            onRequest: onRequest
        };
    }); // testing 123
