/**
 * @NApiVersion 2.0
 * @NScriptType MapReduceScript
 * Testing for change
 */
// test commit 10/04
define([ 'N/search'], 
		function(search) {
	function getInputData() {
		
	}

	function map(context) {
		
	}

	function summarize(summary) {
		
	}

	return {
		config : {
			exitOnError : true
		},
		getInputData : getInputData,
		map : map,
		summarize : summarize
	};
}); //Test commit on 11/12
