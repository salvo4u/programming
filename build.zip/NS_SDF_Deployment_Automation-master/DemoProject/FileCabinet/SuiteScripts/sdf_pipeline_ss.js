/**
 * Subsidiary/Bill To Association Automation. Scheduled script gets parameters from user event script and update association with subsidiaries based on them
 *
 *@NApiVersion 2.0
 *@NScriptType ScheduledScript
 */
define([ 'N/runtime'],
    function(runtime) {
		function execute(context) {

        }
        return {
            execute: execute
        };
    }); // testing 10/31 testing on 11/13
