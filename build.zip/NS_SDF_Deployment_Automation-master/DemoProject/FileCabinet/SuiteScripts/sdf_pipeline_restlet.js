/**
 *@NApiVersion 2.x
 *@NScriptType Restlet
 */
define(
    [
        'N/search',
        'N/record',
        'N/cache',
        'N/format'
    ],
    function (search, record, cache, fmt) {
        function get (context) {
        }

        return {
            get: get,
        };
    }
);
// testing on 10/31 testing again test this test this test 
